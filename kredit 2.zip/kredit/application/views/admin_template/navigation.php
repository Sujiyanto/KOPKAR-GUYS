

<!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><strong><img src="#" width="30px" height="30px"/>
				&nbsp;&nbsp;</strong></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                         <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li><a href="user-view.php"><i class="fa fa-user fa-fw"></i> Profil Anda</a>
                        </li>
                        <li><a href="user-set.php"><i class="fa fa-gear fa-fw"></i> Pengaturan</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="#"><i class="fa fa-sign-out fa-fw"></i> Keluar</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->
			
			 <!-- /.navbar-left -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Cari di sini">
                                <span class="input-group-btn">
                                    <button class="btn btn-default" type="button">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </span>
                            </div>
                            <!-- /input-group -->
                        </li>
						<li>
                            <a href="dasbor-utama.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
						<li>
                            <a href="aplikasi-atur.php"><i class="fa fa-institution fa-fw"></i> Perusahaan</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-database fa-fw"></i> Master Data<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="barang-list.php"><i class="fa fa-files-o fa-fw"></i>Daftar Barang</a>
                                </li>
                                <li>
                                    <a href="kate-list.php"><i class="fa fa-files-o fa-fw"></i>Daftar Kategori</a>
                                </li>
								<li>
                                    <a href="peminjam-list.php"><i class="fa fa-files-o fa-fw"></i>Daftar Peminjam</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
						
						
				
							<li>
							<a href="#"><i class="fa fa-list fa-fw"></i><span class="fa arrow"></span></a>
								<ul class="nav nav-second-level">
							
					
                                <li>
                                    <a href="#"></a>
                                </li>
						
								</ul>
							</li>
					
                         	
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
