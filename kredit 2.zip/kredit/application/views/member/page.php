<style type="text/css">
	#tabs{
   
    color: #333333;
    height: 250px;
  
  
    align-items: center;
    justify-content: space-around;
    display: flex;
    float: none;
}
</style>
<div class="container">

       				<div id="tabs">
            	 <table>
           	
           		<tr>
           			<td>
                  <a class="btn btn-success btn-lg"><i class="fa fa-desktop fa-lg"></i><br>Elektronik</a></td>
           			<td><a class="btn btn-info btn-lg"><i class="fa fa-cutlery fa-lg"></i><br>Sembako</a></td>
           			<td><a href="<?= base_url('member/kreditan');?>" class="btn btn-warning btn-lg"><i class="fa fa-dollar fa-lg"></i><br>Kredit</a></td>
           			<td><a href="<?= base_url('member/about');?>" class="btn btn-secondary btn-lg"><i class="fa fa-info fa-lg"></i><br>About</a></td>
           		</tr>
           		
           		<tr>
           			
           		</tr>
           

           </table>
           </div>

        

			
          
         


            

            <!--/.col-->            
        </div>
   