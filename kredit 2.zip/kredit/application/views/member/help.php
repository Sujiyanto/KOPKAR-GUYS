<style type="text/css">
	#kananin{
		margin-left: 23px;
	}
</style>

<div class="col-lg-12">
<div class="jumbotron">

	<div class="container">
		<h3 style="color: blue; text-align:center;">BANTUAN</h3>
		<hr width="15%">
		<dl style="margin-left: 29px;">
			<dt style="color: blue;">Registrasi</dt>
			<li id="kananin">Dalam halaman registrasi terdapat tombol untuk daftar, silahkan klik </li>
			<li id="kananin">Isikan semua data yang diminta</li>
			<li id="kananin">Kemudian klik tombol DAFTAR</li>
		</dl>
		<br>
		<dl style="margin-left: 29px;">
			<dt style="color: blue;">Pembelian Barang</dt>
			<li id="kananin">Dalam dashboard terdapat beberapa kategori barang. Silahkan pilih kategori</li>
			<li id="kananin">Isikan semua data yang diminta</li>
			<li id="kananin">Atau bisa menggunakan searh untuk mencari barang yang akan dibeli</li>
		</dl>
		<br>
		<dl style="margin-left: 29px;">
			<dt style="color: blue;">Peminjaman Uang</dt>
			<li id="kananin">Dalam dashboard terdapat menu kredit. Pilih menu tersebut</li>
			<li id="kananin">Kemudian lengkapi form pengajuan permintaan</li>
			
		</dl>
	</div>

</div>
</div>