<div class="jumbotron">
	<div class="container">
	

		<table style="margin-left: 20px;">
			<tr>
				<th style="padding-right: 10px;">NIK</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['nik']?></td>
			</tr>
			<tr>
				<th style="padding-right: 10px;">Nama</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['nama']?></td>
			</tr>
			<tr>
				<th style="padding-right: 10px;">Jenis Kelamin</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['jk']?></td>
			</tr>
			<tr>
				<th style="padding-right: 10px;">Alamat</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['alamat']?></td>
			</tr>
			<tr>
				<th style="padding-right: 10px;">No. Telp</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['nohp']?></td>
			</tr>
			<tr>
				<th style="padding-right: 10px;">Email</th>
				<th>:</th>
				<td style="padding-left: 10px;"><?php echo $rows['email']?></td>
			</tr>
		</table>
	</div>
</div>