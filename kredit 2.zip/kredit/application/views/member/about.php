<style type="text/css">
	#kananin{
		margin-left: 23px;
	}
</style>

<div class="col-lg-12">
	<p style="border: solid 1px #eceff5; background: grey; padding: 13px; margin-right: 0; text-align: justify; line-height: 23px; color: white; font-size: 18px"><i style="padding-left: 465px; color: black;" class="fa fa-info fa-lg"> About</i></p>
<div class="jumbotron">


		<h3 style="color: blue; text-align:center;">About Akbar Kopkar Apps</h3>
		<br>
	
		<p style="text-align: justify; padding-left: 210px;">AKBAR KOPKAR adalah Aplikasi Kredit Barang dari Koperasi Karyawan Polindra.<br/> Aplikasi ini dibuat untuk memenuhi tugas besar yang dirancang oleh : <br><br>
			Astri Alisah(1603091)<br>
			Muhammad Fauzi Al Fariz (1603107)<br>
			Nur Inayatun Mahmuda (1603109)<br>
			Sujiyanto (1603112)
</p>
		
	

</div>
</div>