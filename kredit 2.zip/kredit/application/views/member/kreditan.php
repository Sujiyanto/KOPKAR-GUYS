

<div class="col-lg-12">
	<p style="border: solid 1px #eceff5; background: orange; padding: 13px; margin-right: 0; text-align: justify; line-height: 23px; color: white; font-size: 18px"><i style="padding-left: 465px; color: black;" class="fa fa-dollar fa-lg"> Kredit</i></p>
<br>
<div class="jumbotron">
	<p>Form Pengajuan Pinjaman</p>
<br>
	<form method="post" action="">
		<div class="form-group row">
			<label for="example-text-input" class="col-2 col-form-label">Nama</label>
			<div class="col-5">
				<input class="form-control" type="text" name="nama" id="example-text-input">
			</div>
		</div>
		<div class="form-group row">
			<label for="example-text-input" class="col-2 col-form-label">Jumlah Pinjaman</label>
			<div class="col-5">
				<input class="form-control" type="text" name="jumlah" id="example-text-input">
			</div>
		</div>
		<div class="form-group row">
			<label for="example-text-input" class="col-2 col-form-label">Jangka Waktu</label>
			<div class="col-5">
				<select class="form-control" id="exampleSelect1">
					<option>3 Bulan</option>
					<option>6 Bulan</option>
					<option>12 Bulan</option>
			
				</select>					
			</div>
			</div>
			<a href="" class="btn btn-primary">Ajukan</a>
		</form>
	</div>
	</div>
	
