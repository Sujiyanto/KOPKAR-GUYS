<?php
 echo "<pre>";
 	print_r($rows['nama']);
 	echo "<br>";
 	print_r($rows['alamat']);
 echo "</pre>";
// var_dump($rows['nik']);
	
?>